## 1.1.0
* 迁移至.NET 6

## 1.0.7
* 修复微信登录/QQ登录/微博登录 Invalid type parameter 'Microsoft.AspNetCore.Mvc.RedirectResult' specified for 'ActionResult' 报错

## 1.0.6
* 修复Method not found: 'System.Threading.Tasks.Task SSCMS.Repositories.ILogRepository.AddUserLogAsync(SSCMS.Models.User, System.String, System.String)'.报错

## 1.0.5
* 增加API独立部署支持

## 1.0.4
* 增加用户操作日志

## 1.0.3
* 更换ICacheManager接口

## 1.0.2
* 新增模板编辑功能

## 1.0.1
* 修复登录报错提示信息显示

## 1.0.0
* 从 .NET FRAMEWORK 迁移至 .NET CORE 平台