﻿---
name: Zotikos
coverUrl: /images/theme/cover.png
price: 0
thumbUrls:
  - /images/theme/thumb1.png
  - /images/theme/thumb2.png
  - /images/theme/thumb3.png
summary: 这是一套响应式网站模版，适用于企业建站、新闻发布、产品展示，整体效果绚丽。
tags:
  - 蓝色
  - 响应式
compatibilities:
  - SSCMS 7.0.x
  - SSCMS 6.15.x
---

## Zotikos

这是一套响应式网站模版，适用于企业建站、新闻发布、产品展示，整体效果绚丽。
