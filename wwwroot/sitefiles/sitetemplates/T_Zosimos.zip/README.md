﻿---
name: Zosimos
coverUrl: /images/theme/cover.png
price: 0
thumbUrls:
  - /images/theme/thumb1.png
  - /images/theme/thumb2.png
  - /images/theme/thumb3.png
summary: 这是一套响应式网站模版，适用于企业官网、资讯发布、专题网站，整体大气简洁。
tags:
  - 响应式
  - 企业官网
  - 专题
compatibilities:
  - SSCMS 7.0.x
  - SSCMS 6.15.x
---

## Zosimos

这是一套响应式网站模版，适用于企业官网、资讯发布、专题网站，整体大气简洁。
