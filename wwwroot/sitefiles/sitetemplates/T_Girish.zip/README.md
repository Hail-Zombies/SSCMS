﻿---
name: Girish
coverUrl: /images/theme/cover.png
price: 0
thumbUrls:
  - /images/theme/thumb1.png
  - /images/theme/thumb2.png
  - /images/theme/thumb3.png
summary: 自适应的资讯模板，模板包含有评论、注册登录、搜索、文章排行、专题等模块，适合资讯密集型网站使用。
tags:
  - 响应式
  - 资讯站
compatibilities:
  - SSCMS 7.0.x
  - SSCMS 6.15.x
---

## Girish

自适应的资讯模板，模板包含有评论、注册登录、搜索、文章排行、专题等模块，适合资讯密集型网站使用。
