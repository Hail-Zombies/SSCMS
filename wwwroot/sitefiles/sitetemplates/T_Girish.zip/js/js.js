jQuery(document).ready(function($){

/*banner*/
var swiper = new Swiper('.swiper-container', {
	pagination: '.bannav',
	paginationClickable: true,
	nextButton: '.banleft',
	prevButton: '.banright',
	loop : true,
	 autoplay: 3000
});

});
